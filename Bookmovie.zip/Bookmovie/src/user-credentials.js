
const userData = {
users:[
    {username: 'admin', password: 'adminpassword'},
    {username: 'admin1', password: 'admin1password'},
    {username: 'admin2', password: 'admin2password'}
]


}
export {userData};