

const Favourites = () =>{

    return (
        <div style={{backgroundColor:"lightpink",height:"40px"}}>
     <div style={{fontWeight:"bold",paddingTop:"8px"}}> My Favourite Movies</div>
     </div>
    )
}
export{Favourites}